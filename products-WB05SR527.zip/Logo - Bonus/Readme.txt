LOGO SOURCES

FLA
Adobne Flash 	- the logo was originaly created on Adobe Flash CS3

ILLUSTRATOR
Aobe Illustrator- vectorial - use it for print

PNG
Exported png 	- transparent background 2000x2000px

PDF
Exported PDF	- high quality (print quality)