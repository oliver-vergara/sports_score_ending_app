Recommended: Do no delete images - all of them are used on various sections:
	page-coming-soon-image.html
	page-coming-soon-video.html
	page-maintenance.html

Be sure you change html files before to delte images from this folder!